const { ApplicationCommandType } = require("discord.js");
const { Painel } = require("../../FunctionsAll/PainelTicket");

// Defina o ID do usuário autorizado
const allowedUserId = "1327453790147838014"; // Substitua pelo ID do usuário permitido

module.exports = {
  name: "painel",
  description: "[🤖] Use para configurar o sistema de ticket",
  type: ApplicationCommandType.ChatInput,

  run: async (client, interaction) => {
    if (interaction.user.id !== allowedUserId) {
      await interaction.reply({ 
        ephemeral: true, 
        content: "❌ Você não tem permissão para usar este comando."
      });
      return;
    }

    Painel(interaction, client);
  }
};
